#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->actionCopy, &QAction::triggered, this,
            &MainWindow::copy);
    connect(ui->actionCut, &QAction::triggered, this,
            &MainWindow::cut);
    connect(ui->actionPaste, &QAction::triggered, this,
            &MainWindow::paste);
    connect(ui->actionRedimensionner, &QAction::triggered, this, &MainWindow::resizeImage);
    connect(ui->actionD_placer, &QAction::triggered, this, &MainWindow::moveImage);
    connect(ui->actionSupprimer, &QAction::triggered, this, &MainWindow::deleteImage);
    connect(ui->textEdit, &QTextEdit::anchorClicked, this, &MainWindow::handleAnchorClicked);




}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionNew_triggered()
{
    currentFile.clear();
    ui->textEdit->setText(QString());

}


void MainWindow::on_actionOpen_triggered()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Open the file");
    if (fileName.isEmpty())
        return;
    QFile file(fileName);
    currentFile = fileName;
    if (!file.open(QIODevice::ReadOnly | QFile::Text)) {
        QMessageBox::warning(this, "Warning", "Cannot open file: " +
                                                  file.errorString());
        return;
    }
    setWindowTitle(fileName);
    QTextStream in(&file);
    QString text = in.readAll();
    ui->textEdit->setText(text);
    file.close();
}


void MainWindow::on_actionSave_triggered()
{
    QString fileToSave;
    if(currentFile.size()==0){
        fileToSave = QFileDialog::getSaveFileName(this, "Choose a file name");
    }else{
        fileToSave =currentFile;
    }
    QFile file(fileToSave+".txt");
    QString fileContent = ui->textEdit->toPlainText();
    if(file.open(QFile::WriteOnly | QFile::Text)){
        QTextStream in(&file);
        in<<fileContent;
        file.close();
    }
}


void MainWindow::on_actionSave_as_triggered()
{
    QString fileToSave = QFileDialog::getSaveFileName(this, "Choose a file name");
    QFile file(fileToSave+".txt");
    QString fileContent = ui->textEdit->toPlainText();
    if(file.open(QFile::WriteOnly | QFile::Text)){
        QTextStream in(&file);
        in<<fileContent;
        file.close();
    }
}


void MainWindow::on_actionExit_triggered()
{
    QApplication::exit();
}


void MainWindow::on_actionFont_triggered()
{
    bool fontSelected;
    QFont font = QFontDialog::getFont(&fontSelected, this);
    if (fontSelected)
        ui->textEdit->setCurrentFont(font);
}

void MainWindow::setItalic(bool italic)
{
    ui->textEdit->setFontItalic(italic);
}

void MainWindow::setUnderline(bool underline)
{
    ui->textEdit->setFontUnderline(underline);
}

void MainWindow::setBold(bool bold)
{
    ui->textEdit->setFontWeight(bold ? QFont::Bold: QFont::Normal);
}

void MainWindow::about(){
    QMessageBox::about(this, "About",tr("Ceci est un about"));
}

void MainWindow::on_actionAbout_triggered()
{
    about();
}

void MainWindow::copy(){
    ui->textEdit->copy();
}

void MainWindow::paste(){
    ui->textEdit->paste();
}
    QString selectedImageUrl;
void MainWindow::cut(){
    ui->textEdit->cut();
}

void MainWindow::on_actionColor_triggered()
{
    ui->textEdit->setTextColor(QColorDialog::getColor(Qt::white, this, "Couleur",QColorDialog::ColorDialogOptions()));
}


void MainWindow::on_actionImporter_triggered()
{
    QString imagePath = QFileDialog::getOpenFileName(this, "Sélectionner une image", "", "Images (*.png *.jpg *.jpeg)");
    QString htmlImageTag = QString("<img src=\"%1\">").arg(imagePath);
    ui->textEdit->insertHtml(htmlImageTag);
}


void MainWindow::on_actionRendu_triggered()
{
    QString htmlContent = ui->textEdit->toHtml();
    ui->textBrowser->setHtml(htmlContent);
}

void MainWindow::resizeImage()
{
    QTextCursor cursor = ui->textEdit->textCursor();
    cursor.select(QTextCursor::Document);

    QString selectedText = cursor.selectedText();
    QString imageTag = "<img";

    if (selectedText.contains(imageTag))
    {
        int startPos = selectedText.indexOf(imageTag);
        int endPos = selectedText.indexOf(">", startPos) + 1;

        QString imageSelection = selectedText.mid(startPos, endPos - startPos);

        bool ok;
        QString newSize = QInputDialog::getText(this, "Resize Image", "Enter new size (e.g., widthxheight):", QLineEdit::Normal, "", &ok);

        if (ok && !newSize.isEmpty())
        {
            QString resizedImage = imageSelection;
            resizedImage.replace(QRegExp("width=\"(\\d+)\""), "width=\"" + newSize.section('x', 0, 0) + "\"");
            resizedImage.replace(QRegExp("height=\"(\\d+)\""), "height=\"" + newSize.section('x', 1, 1) + "\"");

            cursor.removeSelectedText();
            cursor.insertHtml(resizedImage);
        }
    }
    else
    {
        QMessageBox::information(this, "No Image Selected", "Please select an image to resize.");
    }
}


void MainWindow::moveImage()
{
    QTextCursor cursor = ui->textEdit->textCursor();
    cursor.select(QTextCursor::Document);
    QString selectedText = cursor.selectedText();

    if (selectedText.contains("<img"))
    {
        // Code pour déplacer l'image
        // Ici, tu peux mettre en œuvre la logique permettant de détecter le déplacement de l'image
        // et de mettre à jour les coordonnées de l'image dans la balise <img>
        // Une approche possible est d'ajouter des gestionnaires d'événements de souris
        // pour suivre le déplacement de l'image et mettre à jour les coordonnées en conséquence.
        // Par exemple, tu peux utiliser des signaux tels que mousePressEvent, mouseMoveEvent et mouseReleaseEvent
    }
    else
    {
        QMessageBox::information(this, "No Image Selected", "Please select an image to move.");
    }
}

void MainWindow::deleteImage()
{
    QTextCursor cursor = ui->textEdit->textCursor();
    cursor.select(QTextCursor::Document);
    QString selectedText = cursor.selectedText();

    if (selectedText.contains("<img"))
    {
        cursor.removeSelectedText();
    }
    else
    {
        QMessageBox::information(this, "No Image Selected", "Please select an image to delete.");
    }
}

void MainWindow::handleAnchorClicked(const QUrl& url)
{
    // Vérifie si le lien est une image
    if (url.scheme() == "image")
    {
        // Récupère l'URL de l'image
        QString imageUrl = url.path();

        // Met à jour la variable selectedImageUrl
        selectedImageUrl = imageUrl;

        // Fais ce que tu souhaites lorsque l'image est sélectionnée (par exemple, affiche un message)
        QMessageBox::information(this, "Image Selected", "Image URL: " + selectedImageUrl);
    }
}


